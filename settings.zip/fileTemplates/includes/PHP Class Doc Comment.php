/**
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 * @author Claude Simo <jeanclaude.simo@abus-kransysteme.de>
 * @copyright ABUS Kransysteme GmbH
 * @license proprietary
 */
